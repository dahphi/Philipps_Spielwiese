-- liquibase formatted sql
-- changeset RK_MAIN:1774555709070 stripComments:false logicalFilePath:SCDP/rk_main/object_grants/object_grants_as_grantor.rk_main.table.ad_abteilungsaccount.sql runAlways:false runOnChange:false replaceIfExists:true failOnError:true
-- sqlcl_snapshot RK_MAIN/src/database/rk_main/object_grants/object_grants_as_grantor.rk_main.table.ad_abteilungsaccount.sql:null:5ad51f21faf200cc68a056871ad91289a7bd43db:create

grant select on rk_main.ad_abteilungsaccount to rk_apex;

grant read on rk_main.ad_abteilungsaccount to rk_read;

