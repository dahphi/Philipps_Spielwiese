-- liquibase formatted sql
-- changeset RK_MAIN:1774554918610 stripComments:false logicalFilePath:SCDP/rk_main/package_bodies/pck_isr_massnahmenkomplexitaet_dml.sql runAlways:false runOnChange:false replaceIfExists:true failOnError:true
-- sqlcl_snapshot RK_MAIN/src/database/rk_main/package_bodies/pck_isr_massnahmenkomplexitaet_dml.sql:null:7e11fa9f716a21165a50363a63919f11f21ef418:create

create or replace package body rk_main.pck_isr_massnahmenkomplexitaet_dml as

  -- Variablen etc.
    gcv_package_name constant varchar2(100) := $$plsql_unit;

---------------------------------------------------------------------------------------------------

    function fv_print (
        pir_row         in isr_massnahmenkomplexitaet%rowtype,
        piv_output_type in varchar2 default 'no'
    ) return varchar2 is
        cv_sep   constant varchar2(100) := '###cr###';
        v_retval varchar2(32767);
    begin
        if ( piv_output_type in ( 'no', 'pretty' ) ) then
            v_retval := 'mkp_uid = '
                        || to_char(pir_row.mkp_uid)
                        || cv_sep
                        || ', mkp_bezeichnung = '
                        || pir_row.mkp_bezeichnung
                        || cv_sep
                        || ', mkp_beschreibung = '
                        || pir_row.mkp_beschreibung
                        || cv_sep
                        || ', inserted = '
                        || to_char(pir_row.inserted, 'DD.MM.YYYY')
                        || cv_sep
                        || ', updated = '
                        || to_char(pir_row.updated, 'DD.MM.YYYY')
                        || cv_sep
                        || ', inserted_by = '
                        || pir_row.inserted_by
                        || cv_sep
                        || ', updated_by = '
                        || pir_row.updated_by
                        || cv_sep;

            if ( piv_output_type = 'no' ) then
                v_retval := replace(
                    trim(v_retval),
                    cv_sep,
                    null
                );
            else
                v_retval := replace(
                    trim(v_retval),
                    cv_sep,
                    chr(10)
                );
            end if;

        elsif ( piv_output_type = 'html' ) then
            v_retval := '<table><tr><th>ISR_MASSNAHMENKOMPLEXITAET</th><th>Column</th></tr>'
                        || '<tr><td>mkp_uid</td><td>'
                        || to_char(pir_row.mkp_uid)
                        || '</td></tr>'
                        || '<tr><td>mkp_bezeichnung</td><td>'
                        || pir_row.mkp_bezeichnung
                        || '</td></tr>'
                        || '<tr><td>mkp_beschreibung</td><td>'
                        || pir_row.mkp_beschreibung
                        || '</td></tr>'
                        || '<tr><td>inserted</td><td>'
                        || to_char(pir_row.inserted, 'DD.MM.YYYY')
                        || '</td></tr>'
                        || '<tr><td>updated</td><td>'
                        || to_char(pir_row.updated, 'DD.MM.YYYY')
                        || '</td></tr>'
                        || '<tr><td>inserted_by</td><td>'
                        || pir_row.inserted_by
                        || '</td></tr>'
                        || '<tr><td>updated_by</td><td>'
                        || pir_row.updated_by
                        || '</td></tr>'
                        || '</table>';
        else
            v_retval := null;
        end if;

        return v_retval;
    end fv_print;

---------------------------------------------------------------------------------------------------

    procedure p_insert (
        pior_isr_massnahmenkomplexitaet in out isr_massnahmenkomplexitaet%rowtype
    ) is

  -- fuer exceptions
        v_routine_name logs.routine_name%type;
        c_message      clob;
    begin
  -- fuer exceptions
        v_routine_name := gcv_package_name || '.P_INSERT';
        pior_isr_massnahmenkomplexitaet.inserted := sysdate;
        pior_isr_massnahmenkomplexitaet.inserted_by := pck_env.fv_user;
        insert into isr_massnahmenkomplexitaet values pior_isr_massnahmenkomplexitaet returning mkp_uid into pior_isr_massnahmenkomplexitaet.mkp_uid
        ;

    exception
        when others then
    -- Fehlerprotokollierung
            c_message := 'Fehler bei Insert in Tabelle isr_massnahmenkomplexitaet! Parameter: ' || fv_print(pir_row => pior_isr_massnahmenkomplexitaet
            );
            pck_logs.p_error(
                piv_routine_name => v_routine_name,
                pic_message      => c_message
            );
            raise;
    end p_insert;

-------------------------------------------------------------------------------

    procedure p_merge (
        pir_isr_massnahmenkomplexitaet in isr_massnahmenkomplexitaet%rowtype
    ) is
        r_isr_massnahmenkomplexitaet isr_massnahmenkomplexitaet%rowtype;

  -- fuer exceptions
        v_routine_name               logs.routine_name%type;
        c_message                    clob;
    begin
  -- fuer exceptions
        v_routine_name := gcv_package_name || '.P_MERGE';
        r_isr_massnahmenkomplexitaet := pir_isr_massnahmenkomplexitaet;
        r_isr_massnahmenkomplexitaet.inserted := sysdate;
        r_isr_massnahmenkomplexitaet.updated := sysdate;
        r_isr_massnahmenkomplexitaet.inserted_by := pck_env.fv_user;
        r_isr_massnahmenkomplexitaet.updated_by := pck_env.fv_user;
        merge into isr_massnahmenkomplexitaet
        using dual on ( mkp_uid = r_isr_massnahmenkomplexitaet.mkp_uid )
        when matched then update
        set mkp_bezeichnung = r_isr_massnahmenkomplexitaet.mkp_bezeichnung,
            mkp_beschreibung = r_isr_massnahmenkomplexitaet.mkp_beschreibung,
            updated = r_isr_massnahmenkomplexitaet.updated,
            updated_by = r_isr_massnahmenkomplexitaet.updated_by
        when not matched then
        insert (
            mkp_bezeichnung,
            mkp_beschreibung,
            inserted,
            inserted_by )
        values
            ( r_isr_massnahmenkomplexitaet.mkp_bezeichnung,
              r_isr_massnahmenkomplexitaet.mkp_beschreibung,
              r_isr_massnahmenkomplexitaet.inserted,
              r_isr_massnahmenkomplexitaet.inserted_by );

    exception
        when others then
    -- Fehlerprotokollierung
            c_message := 'Fehler bei Merge! Parameter: ' || fv_print(pir_row => pir_isr_massnahmenkomplexitaet);
            pck_logs.p_error(
                piv_routine_name => v_routine_name,
                pic_message      => c_message
            );
            raise;
    end p_merge;

---------------------------------------------------------------------------------------------------

    procedure p_update (
        pir_isr_massnahmenkomplexitaet in isr_massnahmenkomplexitaet%rowtype,
        piv_art                        in varchar2
    ) is
        r_isr_massnahmenkomplexitaet isr_massnahmenkomplexitaet%rowtype;

  -- fuer exceptions
        v_routine_name               logs.routine_name%type;
        c_message                    clob;
    begin
  -- fuer exceptions
        v_routine_name := gcv_package_name || '.P_UPDATE';
        r_isr_massnahmenkomplexitaet.mkp_bezeichnung := pir_isr_massnahmenkomplexitaet.mkp_bezeichnung;
        r_isr_massnahmenkomplexitaet.mkp_beschreibung := pir_isr_massnahmenkomplexitaet.mkp_beschreibung;
        r_isr_massnahmenkomplexitaet.updated := sysdate;
        r_isr_massnahmenkomplexitaet.updated_by := pck_env.fv_user;
        case piv_art
            when '<replace>' then
                update isr_massnahmenkomplexitaet
                set
                    mkp_uid = pir_isr_massnahmenkomplexitaet.mkp_uid
                where
                    mkp_uid = pir_isr_massnahmenkomplexitaet.mkp_uid;

            when '<full>' then    
      -- Übernehmen der Eingabedaten  
                r_isr_massnahmenkomplexitaet := pir_isr_massnahmenkomplexitaet;  
      -- Ergänzen der Anlagedaten  
                select
                    inserted,
                    inserted_by
                into
                    r_isr_massnahmenkomplexitaet.inserted,
                    r_isr_massnahmenkomplexitaet.inserted_by
                from
                    isr_massnahmenkomplexitaet
                where
                    mkp_uid = pir_isr_massnahmenkomplexitaet.mkp_uid;  
      -- Ergänzen der Update-Daten  
                r_isr_massnahmenkomplexitaet.updated := sysdate;
                r_isr_massnahmenkomplexitaet.updated_by := pck_env.fv_user;
                update isr_massnahmenkomplexitaet
                set
                    row = r_isr_massnahmenkomplexitaet
                where
                    mkp_uid = pir_isr_massnahmenkomplexitaet.mkp_uid;

            else
                raise_application_error(-20000, 'Parameter wird nicht unterstuetzt!');
        end case;

    exception
        when others then
    -- Fehlerprotokollierung
            c_message := 'Fehler bei Update! Parameter: ' || fv_print(pir_row => pir_isr_massnahmenkomplexitaet);
            pck_logs.p_error(
                piv_routine_name => v_routine_name,
                pic_message      => c_message
            );
            raise;
    end p_update;

---------------------------------------------------------------------------------------------------

    procedure p_delete (
        pin_mkp_uid in isr_massnahmenkomplexitaet.mkp_uid%type
    ) is

  -- fuer exceptions
        v_routine_name logs.routine_name%type;
        v_parameter    varchar2(4000);
        c_message      clob;
        e_no_data exception;
    begin
  -- fuer exceptions
        v_routine_name := gcv_package_name || '.P_DELETE';
        v_parameter := 'Parameter: pin_mkp_uid: ' || to_char(pin_mkp_uid);
        delete from isr_massnahmenkomplexitaet
        where
            mkp_uid = pin_mkp_uid;

        if sql%notfound then
            raise e_no_data;
        end if;
    exception
        when e_no_data then
    -- nur Hinweis fuer evt. Fehlersuche
            c_message := 'Hinweis! Zu loeschender DS existiert nicht. Tabelle isr_massnahmenkomplexitaet! ' || v_parameter;
            pck_logs.p_error_exp(
                piv_routine_name => v_routine_name,
                pic_message      => c_message
            );
        when others then
    -- Fehlerprotokollierung
            c_message := 'Fehler beim Loeschen in Tabelle isr_massnahmenkomplexitaet! ' || v_parameter;
            pck_logs.p_error(
                piv_routine_name => v_routine_name,
                pic_message      => c_message
            );
            raise;
    end p_delete;

end pck_isr_massnahmenkomplexitaet_dml;
/

