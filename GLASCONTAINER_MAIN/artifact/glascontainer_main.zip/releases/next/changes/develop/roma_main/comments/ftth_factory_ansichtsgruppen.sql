-- liquibase formatted sql
-- changeset roma_main:1768484669888 stripComments:false logicalFilePath:develop/roma_main/comments/ftth_factory_ansichtsgruppen.sql runAlways:false runOnChange:false replaceIfExists:true failOnError:true
-- sqlcl_snapshot GLASCONTAINER_MAIN/src/database/roma_main/comments/ftth_factory_ansichtsgruppen.sql:null:5e5d62d850e966ad747cfa91bb69d10d94928c84:create

comment on table ftth_factory_ansichtsgruppen is
    'Kontrolle der Umsetzung der Fachkonzepte im #Ticket #CR3230. Wird verwendet in APEX 2022 Glascontainer. Nach Fertigstellung des MVP loeschbar.'
    ;

