-- liquibase formatted sql
-- changeset ROMA_MAIN:1768484684769 stripComments:false logicalFilePath:develop/roma_main/sequences/gc_task_seq.sql runAlways:false runOnChange:false replaceIfExists:true failOnError:true
-- sqlcl_snapshot GLASCONTAINER_MAIN/src/database/roma_main/sequences/gc_task_seq.sql:null:707eb73ec0e91fe821ec580427561f4ffad8fa22:create

create sequence gc_task_seq minvalue 1 maxvalue 9999999999999999999999999999 increment by 1 start with 2545 nocache noorder nocycle nokeep
noscale global;

