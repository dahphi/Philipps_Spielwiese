-- liquibase formatted sql
-- changeset ROMA_MAIN:1768484685109 stripComments:false logicalFilePath:develop/roma_main/views/v_ftth_provider.sql runAlways:false runOnChange:false replaceIfExists:true failOnError:true
-- sqlcl_snapshot GLASCONTAINER_MAIN/src/database/roma_main/views/v_ftth_provider.sql:null:e5ddd4237c59bc7b21335753b1cdaf1723fe1239:create

create or replace force editionable view v_ftth_provider (
    r,
    d1,
    d_siebel
) as
    select
        pv_key2 as r,
        v_wert1 as d1,
        v_wert2 as d_siebel
    from
        params
    where
        pv_key1 = 'FTTH_PROVIDER';

