-- liquibase formatted sql
-- changeset ROMA_MAIN:1768484684760 stripComments:false logicalFilePath:develop/roma_main/ref_constraints/ftth_preorders_fuzzy_requ_fk.sql runAlways:false runOnChange:false replaceIfExists:true failOnError:true
-- sqlcl_snapshot GLASCONTAINER_MAIN/src/database/roma_main/ref_constraints/ftth_preorders_fuzzy_requ_fk.sql:null:cd42cd55fb1207db51cbf1a1778d466e0e85b6f5:create

alter table ftth_preorders_fuzzydouble
    add constraint ftth_preorders_fuzzy_requ_fk
        foreign key ( request_id )
            references ftth_fuzzy_requests ( id )
                on delete cascade
        enable;

