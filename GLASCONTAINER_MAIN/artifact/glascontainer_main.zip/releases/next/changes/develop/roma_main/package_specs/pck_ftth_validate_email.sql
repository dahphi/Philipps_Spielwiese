-- liquibase formatted sql
-- changeset ROMA_MAIN:1768484683547 stripComments:false logicalFilePath:develop/roma_main/package_specs/pck_ftth_validate_email.sql runAlways:false runOnChange:false replaceIfExists:true failOnError:true
-- sqlcl_snapshot GLASCONTAINER_MAIN/src/database/roma_main/package_specs/pck_ftth_validate_email.sql:null:c8456205ec472e2b4eabd053ded87de69b2ba6e0:create

create or replace package pck_ftth_validate_email as
    -- Konstanten für Logging und Webservice-Kontext
    c_scope constant varchar2(30 char) := 'pck_ftth_validate_email';
    c_kontext constant varchar2(20 char) := 'WEBSERVICE';
    c_key1 constant varchar2(30 char) := 'FTTH_EMAIL_VALIDATION';
    c_key2 constant varchar2(20 char) := 'BASE_URL';

    -- Funktion: Validiert eine E-Mail-Adresse
    -- @param pi_email E-Mail-Adresse als Eingabe
    -- @return 'TRUE' bei Erfolg, sonst Fehlermeldung
    function f_validate_email (
        pi_email in varchar2
    ) return varchar2;

end pck_ftth_validate_email;
/

