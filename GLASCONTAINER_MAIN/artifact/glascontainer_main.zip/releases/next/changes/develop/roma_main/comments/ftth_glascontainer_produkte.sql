-- liquibase formatted sql
-- changeset roma_main:1768484669909 stripComments:false logicalFilePath:develop/roma_main/comments/ftth_glascontainer_produkte.sql runAlways:false runOnChange:false replaceIfExists:true failOnError:true
-- sqlcl_snapshot GLASCONTAINER_MAIN/src/database/roma_main/comments/ftth_glascontainer_produkte.sql:null:4b053ed73f2092e1022199c296339b13f44fbd81:create

comment on table ftth_glascontainer_produkte is
    'Definitionstabelle für aktuelle und inzwischen abgelöste Produkte in der APEX App 2022 (Glascontainer)';

