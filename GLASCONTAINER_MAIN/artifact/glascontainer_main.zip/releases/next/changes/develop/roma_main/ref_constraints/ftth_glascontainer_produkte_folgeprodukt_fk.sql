-- liquibase formatted sql
-- changeset ROMA_MAIN:1768484684753 stripComments:false logicalFilePath:develop/roma_main/ref_constraints/ftth_glascontainer_produkte_folgeprodukt_fk.sql runAlways:false runOnChange:false replaceIfExists:true failOnError:true
-- sqlcl_snapshot GLASCONTAINER_MAIN/src/database/roma_main/ref_constraints/ftth_glascontainer_produkte_folgeprodukt_fk.sql:null:bf45755b46c31378ad5dd7001a2117ed154ca308:create

alter table ftth_glascontainer_produkte
    add constraint ftth_glascontainer_produkte_folgeprodukt_fk
        foreign key ( folgeprodukt_template_id )
            references ftth_glascontainer_produkte ( template_id )
        enable;

