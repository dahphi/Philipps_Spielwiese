-- liquibase formatted sql
-- changeset ROMA_MAIN:1768484684741 stripComments:false logicalFilePath:develop/roma_main/ref_constraints/ftth_fuzzy_requests_ftth_fk.sql runAlways:false runOnChange:false replaceIfExists:true failOnError:true
-- sqlcl_snapshot GLASCONTAINER_MAIN/src/database/roma_main/ref_constraints/ftth_fuzzy_requests_ftth_fk.sql:null:57cd2e3945219647bf309ea3ee14cb6f372520fb:create

alter table ftth_fuzzy_requests
    add constraint ftth_fuzzy_requests_ftth_fk
        foreign key ( ftth_id )
            references ftth_ws_sync_preorders ( id )
                on delete cascade
        enable;

