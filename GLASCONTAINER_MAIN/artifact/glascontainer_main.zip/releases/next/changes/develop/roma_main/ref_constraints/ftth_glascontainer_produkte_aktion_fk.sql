-- liquibase formatted sql
-- changeset ROMA_MAIN:1768484684747 stripComments:false logicalFilePath:develop/roma_main/ref_constraints/ftth_glascontainer_produkte_aktion_fk.sql runAlways:false runOnChange:false replaceIfExists:true failOnError:true
-- sqlcl_snapshot GLASCONTAINER_MAIN/src/database/roma_main/ref_constraints/ftth_glascontainer_produkte_aktion_fk.sql:null:a94296af2d0ba333ed07d4c775d69533b47cf4ca:create

alter table ftth_glascontainer_produkte
    add constraint ftth_glascontainer_produkte_aktion_fk
        foreign key ( aktion )
            references ftth_glascontainer_aktionen ( code )
        enable;

