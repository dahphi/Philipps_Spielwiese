-- liquibase formatted sql
-- changeset ROMA_MAIN:1768484684826 stripComments:false logicalFilePath:develop/roma_main/tables/ftth_glascontainer_aktionen.sql runAlways:false runOnChange:false replaceIfExists:true failOnError:true
-- sqlcl_snapshot GLASCONTAINER_MAIN/src/database/roma_main/tables/ftth_glascontainer_aktionen.sql:null:bb898a77760644ca40edbbe0d3c5cf1516ca54db:create

create table ftth_glascontainer_aktionen (
    code        varchar2(30 byte) not null enable,
    name        varchar2(100 byte) not null enable,
    gueltig_ab  date,
    gueltig_bis date,
    aktuell     number(1, 0),
    status      varchar2(1 byte)
);

alter table ftth_glascontainer_aktionen
    add constraint ftth_glascontainer_aktionen_pk primary key ( code )
        using index enable;

